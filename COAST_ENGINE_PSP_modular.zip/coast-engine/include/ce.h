#ifndef COAST_ENGINE_CE_H
#define COAST_ENGINE_CE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CE_SCREEN_WIDTH  480
#define CE_SCREEN_HEIGHT 272

typedef struct {
    unsigned char r, g, b, a;
} CEColor;

typedef enum {
    CE_KEY_UP       = 1u << 0,
    CE_KEY_DOWN     = 1u << 1,
    CE_KEY_LEFT     = 1u << 2,
    CE_KEY_RIGHT    = 1u << 3,
    CE_KEY_CROSS    = 1u << 4,
    CE_KEY_CIRCLE   = 1u << 5,
    CE_KEY_SQUARE   = 1u << 6,
    CE_KEY_TRIANGLE = 1u << 7,
    CE_KEY_START    = 1u << 8,
    CE_KEY_SELECT   = 1u << 9,
    CE_KEY_L        = 1u << 10,
    CE_KEY_R        = 1u << 11
} CEKey;

int   CE_Init(void);
void  CE_Shutdown(void);
void  CE_Update(void);
float CE_DeltaTime(void);

int CE_KeyDown(CEKey key);
int CE_KeyPressed(CEKey key);
int CE_KeyReleased(CEKey key);

void CE_BeginFrame(CEColor clearColor);
void CE_DrawRect(int x, int y, int width, int height, CEColor color);
void CE_EndFrame(void);

int  CE_AudioInit(void);
void CE_AudioShutdown(void);

int CE_MapInit(int width, int height);
void CE_MapClear(unsigned char value);
int CE_MapSetCell(int x, int y, unsigned char value);
unsigned char CE_MapGetCell(int x, int y);

void *CE_Alloc(size_t size);
void  CE_Free(void *memory);

int CE_SaveWrite(const char *path, const void *data, unsigned int size);
int CE_SaveRead(const char *path, void *data, unsigned int size);

#ifdef __cplusplus
}
#endif

#endif
