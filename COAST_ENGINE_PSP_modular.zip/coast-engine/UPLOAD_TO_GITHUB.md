# Как перенести COAST ENGINE в ветку coast-engine-dev

1. Открой репозиторий `markos456/Tower-defense`.
2. Переключись на ветку `coast-engine-dev` (не на `main`).
3. Скачай и распакуй архив COAST ENGINE.
4. Загрузи содержимое папки `coast-engine` в корень репозитория, сохраняя структуру папок.
5. Подтверди commit именно в `coast-engine-dev`.
6. Открой Actions и проверь сборку.

Если GitHub предлагает заменить существующие файлы, замени `src/main.c`, `Makefile`, `README.md` и `.github/workflows/Build.yml`. Старый `src/main.c` — это код Hamlet TD, он полностью заменяется тестовой точкой входа COAST ENGINE.
