#include "ce_internal.h"

static float g_deltaTime = 1.0f / 60.0f;
static u64 g_previousTime = 0;

int CE_Init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    if (!CE_GraphicsInit())
        return 0;

    if (!CE_AudioInit()) {
        CE_GraphicsShutdown();
        return 0;
    }

    g_previousTime = sceKernelGetSystemTimeWide();
    g_deltaTime = 1.0f / 60.0f;
    return 1;
}

void CE_Shutdown(void) {
    CE_AudioShutdown();
    CE_GraphicsShutdown();
}

void CE_Update(void) {
    u64 now;
    u64 elapsed;

    CE_InputUpdate();
    now = sceKernelGetSystemTimeWide();
    elapsed = now - g_previousTime;
    g_previousTime = now;

    g_deltaTime = (float)elapsed / 1000000.0f;
    if (g_deltaTime < 0.001f) g_deltaTime = 0.001f;
    if (g_deltaTime > 0.1f)   g_deltaTime = 0.1f;
}

float CE_DeltaTime(void) {
    return g_deltaTime;
}
