#ifndef COAST_ENGINE_INTERNAL_H
#define COAST_ENGINE_INTERNAL_H

#include "ce.h"
#include <pspkernel.h>
#include <pspctrl.h>

int  CE_GraphicsInit(void);
void CE_GraphicsShutdown(void);
void CE_InputUpdate(void);

#endif
