#include "ce_internal.h"
#include <stdlib.h>

void *CE_Alloc(size_t size) {
    if (size == 0)
        return 0;
    return malloc(size);
}

void CE_Free(void *memory) {
    if (memory)
        free(memory);
}
