#include "ce_internal.h"

#define CE_MAP_MAX_WIDTH  64
#define CE_MAP_MAX_HEIGHT 64

static unsigned char g_cells[CE_MAP_MAX_WIDTH * CE_MAP_MAX_HEIGHT];
static int g_width = 0;
static int g_height = 0;

int CE_MapInit(int width, int height) {
    if (width <= 0 || height <= 0 ||
        width > CE_MAP_MAX_WIDTH || height > CE_MAP_MAX_HEIGHT)
        return 0;

    g_width = width;
    g_height = height;
    CE_MapClear(0);
    return 1;
}

void CE_MapClear(unsigned char value) {
    int i;
    for (i = 0; i < CE_MAP_MAX_WIDTH * CE_MAP_MAX_HEIGHT; ++i)
        g_cells[i] = value;
}

int CE_MapSetCell(int x, int y, unsigned char value) {
    if (x < 0 || y < 0 || x >= g_width || y >= g_height)
        return 0;

    g_cells[y * CE_MAP_MAX_WIDTH + x] = value;
    return 1;
}

unsigned char CE_MapGetCell(int x, int y) {
    if (x < 0 || y < 0 || x >= g_width || y >= g_height)
        return 0;

    return g_cells[y * CE_MAP_MAX_WIDTH + x];
}
