#include "ce_internal.h"

static unsigned int g_currentKeys = 0;
static unsigned int g_previousKeys = 0;

void CE_InputUpdate(void) {
    SceCtrlData pad;
    unsigned int keys = 0;

    g_previousKeys = g_currentKeys;
    sceCtrlPeekBufferPositive(&pad, 1);

    if (pad.Buttons & PSP_CTRL_UP)       keys |= CE_KEY_UP;
    if (pad.Buttons & PSP_CTRL_DOWN)     keys |= CE_KEY_DOWN;
    if (pad.Buttons & PSP_CTRL_LEFT)     keys |= CE_KEY_LEFT;
    if (pad.Buttons & PSP_CTRL_RIGHT)    keys |= CE_KEY_RIGHT;
    if (pad.Buttons & PSP_CTRL_CROSS)    keys |= CE_KEY_CROSS;
    if (pad.Buttons & PSP_CTRL_CIRCLE)   keys |= CE_KEY_CIRCLE;
    if (pad.Buttons & PSP_CTRL_SQUARE)   keys |= CE_KEY_SQUARE;
    if (pad.Buttons & PSP_CTRL_TRIANGLE) keys |= CE_KEY_TRIANGLE;
    if (pad.Buttons & PSP_CTRL_START)    keys |= CE_KEY_START;
    if (pad.Buttons & PSP_CTRL_SELECT)   keys |= CE_KEY_SELECT;
    if (pad.Buttons & PSP_CTRL_LTRIGGER) keys |= CE_KEY_L;
    if (pad.Buttons & PSP_CTRL_RTRIGGER) keys |= CE_KEY_R;

    g_currentKeys = keys;
}

int CE_KeyDown(CEKey key) {
    return (g_currentKeys & (unsigned int)key) != 0;
}

int CE_KeyPressed(CEKey key) {
    unsigned int mask = (unsigned int)key;
    return (g_currentKeys & mask) && !(g_previousKeys & mask);
}

int CE_KeyReleased(CEKey key) {
    unsigned int mask = (unsigned int)key;
    return !(g_currentKeys & mask) && (g_previousKeys & mask);
}
