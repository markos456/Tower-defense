#include "ce_internal.h"
#include <pspgu.h>
#include <pspdisplay.h>

#define CE_BUFFER_WIDTH 512

typedef struct __attribute__((packed)) {
    unsigned int color;
    short x, y, z;
} CEVertex;

static unsigned int g_displayList[262144] __attribute__((aligned(16)));

static unsigned int packColor(CEColor c) {
    return ((unsigned int)c.r) |
           ((unsigned int)c.g << 8) |
           ((unsigned int)c.b << 16) |
           ((unsigned int)c.a << 24);
}

int CE_GraphicsInit(void) {
    sceGuInit();

    sceGuStart(GU_DIRECT, g_displayList);
    sceGuDrawBuffer(GU_PSM_8888, (void *)0, CE_BUFFER_WIDTH);
    sceGuDispBuffer(CE_SCREEN_WIDTH, CE_SCREEN_HEIGHT,
                    (void *)0x88000, CE_BUFFER_WIDTH);
    sceGuDepthBuffer((void *)0x110000, CE_BUFFER_WIDTH);
    sceGuOffset(2048 - (CE_SCREEN_WIDTH / 2),
                2048 - (CE_SCREEN_HEIGHT / 2));
    sceGuViewport(2048, 2048, CE_SCREEN_WIDTH, CE_SCREEN_HEIGHT);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, CE_SCREEN_WIDTH, CE_SCREEN_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuFinish();
    sceGuSync(0, 0);

    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    return 1;
}

void CE_GraphicsShutdown(void) {
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}

void CE_BeginFrame(CEColor clearColor) {
    sceGuStart(GU_DIRECT, g_displayList);
    sceGuClearColor(packColor(clearColor));
    sceGuClear(GU_COLOR_BUFFER_BIT);
}

void CE_DrawRect(int x, int y, int width, int height, CEColor color) {
    CEVertex *vertices;

    if (width <= 0 || height <= 0)
        return;

    vertices = (CEVertex *)sceGuGetMemory(sizeof(CEVertex) * 2);
    if (!vertices)
        return;

    vertices[0].color = packColor(color);
    vertices[0].x = (short)x;
    vertices[0].y = (short)y;
    vertices[0].z = 0;

    vertices[1].color = packColor(color);
    vertices[1].x = (short)(x + width);
    vertices[1].y = (short)(y + height);
    vertices[1].z = 0;

    sceGuDrawArray(GU_SPRITES,
                   GU_COLOR_8888 | GU_VERTEX_16BIT | GU_TRANSFORM_2D,
                   2, 0, vertices);
}

void CE_EndFrame(void) {
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}
