#include "ce_internal.h"
#include <pspiofilemgr.h>

int CE_SaveWrite(const char *path, const void *data, unsigned int size) {
    SceUID file;
    int written;

    if (!path || (!data && size > 0))
        return 0;

    file = sceIoOpen(path, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
    if (file < 0)
        return 0;

    written = sceIoWrite(file, data, size);
    sceIoClose(file);
    return written == (int)size;
}

int CE_SaveRead(const char *path, void *data, unsigned int size) {
    SceUID file;
    int bytesRead;

    if (!path || (!data && size > 0))
        return 0;

    file = sceIoOpen(path, PSP_O_RDONLY, 0777);
    if (file < 0)
        return 0;

    bytesRead = sceIoRead(file, data, size);
    sceIoClose(file);
    return bytesRead == (int)size;
}
