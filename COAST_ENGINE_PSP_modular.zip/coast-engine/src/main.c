#include <pspkernel.h>
#include "ce.h"

PSP_MODULE_INFO("COAST ENGINE", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

static CEColor rgb(unsigned char r, unsigned char g, unsigned char b) {
    CEColor color = { r, g, b, 255 };
    return color;
}

int main(void) {
    float playerX = 228.0f;
    float playerY = 124.0f;
    const float playerSize = 24.0f;
    const float playerSpeed = 190.0f;

    if (!CE_Init()) {
        sceKernelExitGame();
        return 0;
    }

    for (;;) {
        CE_Update();

        float dt = CE_DeltaTime();
        if (CE_KeyDown(CE_KEY_LEFT))  playerX -= playerSpeed * dt;
        if (CE_KeyDown(CE_KEY_RIGHT)) playerX += playerSpeed * dt;
        if (CE_KeyDown(CE_KEY_UP))    playerY -= playerSpeed * dt;
        if (CE_KeyDown(CE_KEY_DOWN))  playerY += playerSpeed * dt;

        if (playerX < 0.0f) playerX = 0.0f;
        if (playerY < 0.0f) playerY = 0.0f;
        if (playerX > CE_SCREEN_WIDTH - playerSize)
            playerX = CE_SCREEN_WIDTH - playerSize;
        if (playerY > CE_SCREEN_HEIGHT - playerSize)
            playerY = CE_SCREEN_HEIGHT - playerSize;

        CE_BeginFrame(rgb(7, 12, 25));
        CE_DrawRect(12, 12, 456, 248, rgb(18, 29, 49));
        CE_DrawRect(20, 20, 440, 2, rgb(58, 190, 160));
        CE_DrawRect(20, 250, 440, 2, rgb(58, 190, 160));
        CE_DrawRect((int)playerX, (int)playerY,
                    (int)playerSize, (int)playerSize,
                    rgb(255, 190, 75));
        CE_EndFrame();

        if (CE_KeyPressed(CE_KEY_START))
            break;
    }

    CE_Shutdown();
    sceKernelExitGame();
    return 0;
}
