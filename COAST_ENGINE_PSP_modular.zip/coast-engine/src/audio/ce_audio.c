#include "ce_internal.h"

/*
 * Audio module placeholder.
 * The engine API is ready; PSP audio channels and mixing will be added here.
 */

int CE_AudioInit(void) {
    return 1;
}

void CE_AudioShutdown(void) {
}
